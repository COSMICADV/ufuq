# UFUQ Visual Identity V2

This package replaces the previous green/cream UI direction for future UFUQ product redesign work.

## Brand direction
- Signature: Navy + Indigo
- Supporting accents: Lavender, Mist Blue, Muted Amber
- Surfaces: White + very light cool canvas
- Personality: trustworthy, forward-looking, people-first, operationally clear
- Arabic-first UI with English parity

## Primary palette
- UFUQ Navy `#171B38`
- UFUQ Indigo `#5748F5`
- Horizon Lavender `#8A7BFF`
- Mist Blue `#EAF0FF`
- Muted Amber `#DDA45A`

## Neutral palette
- White `#FFFFFF`
- Canvas `#F7F8FC`
- Border `#E5E7EF`
- Muted `#667085`
- Text `#20243B`

## Semantic colors
- Success `#168653`
- Error `#DC4242`
- Info `#2165E8`
- Warning `#C77B16`

## Typography
- Arabic: Alexandria
- Latin: Inter
- Display 32 / 700
- H1 28 / 700
- H2 22 / 600-700
- H3 18 / 600
- Body 16 / 400
- Small 14 / 400-500
- Caption 12 / 500

## Shape language
- Card radius: 16px
- Button radius: 12px
- Input height: 48px
- Icon size: 20-24px
- Motion: 150-220ms
- Touch targets: approximately 44px or larger

## Product scope
Dashboard, Employees, Attendance, Leave, Tasks, Goals, Requests, Payroll, Reports, Warehouse, Inventory, Settings, Employee mobile experience, and Public Website.
